## 深度学习实战教程

#### 说明

* get_discuz.py接口已关闭，关闭说明以及验证码环境部署方法，请查看：[Tensorflow实战（二）：Discuz验证码识别](https://cuijiahua.com/blog/2018/01/dl_5.html "悬停显示")