## 深度学习实战教程

#### 说明

* 该系列教程为[@hanbingtao](https://github.com/hanbt/learn_dl "悬停显示")所做，感觉很适合入门，顾转载到了个人网站。开源免费的好教程不多，望多多支持和推荐。

* 可以到我的个人网站看该系列文章：[点击查看](https://cuijiahua.com/blog/dl/ "悬停显示")

* 也可以到原作者的作业部落学习：[点击查看](https://www.zybuluo.com/hanbingtao/note/448086 "悬停显示")