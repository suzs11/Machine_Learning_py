# Image Captionining using Recurrent Neural Networks

Image captioning is done using:
- Vanilla RNN
- LSTMs
- Attention LSTMs

Microsoft COCO Dataset is used

Classes and functions are implemented in they python files. Run the `.ipynb` file to run the code

