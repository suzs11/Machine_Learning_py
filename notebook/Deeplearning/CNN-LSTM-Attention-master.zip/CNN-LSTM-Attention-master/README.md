# CNN-LSTM-Attention
使用卷积神经网络-长短期记忆网络（bi-LSTM）-注意力机制对股票收盘价进行回归预测。The convolution neural network, short-term memory network and attention mechanism are used to predict the closing price.
