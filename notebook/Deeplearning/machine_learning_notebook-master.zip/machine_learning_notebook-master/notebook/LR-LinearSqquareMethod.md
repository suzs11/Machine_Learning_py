# 最小二乘法推导 #

https://blog.csdn.net/qq_32864683/article/details/80368135

y = w0 + w1*x1 + ... + wn*xn
w0为y轴截距项，W1 ... wn权重参数，x1 ... xn为特征参数